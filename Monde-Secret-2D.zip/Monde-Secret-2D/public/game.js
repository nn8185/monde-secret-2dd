const $ = id => document.getElementById(id);
let token = "", socket = null, username = "", players = [], myPos = {x:300,y:300}, keys = {}, lastSent = 0;
const canvas = $("world"), ctx = canvas.getContext("2d");
const W = 2200, H = 1500;
const trees = Array.from({length:100},(_,i)=>({x:((i*197+83)%2100)+50,y:((i*311+121)%1400)+50}));
const rocks = Array.from({length:38},(_,i)=>({x:((i*421+190)%2100)+40,y:((i*173+510)%1400)+40}));
function showGame(){ $("login").classList.add("hidden"); $("game").classList.remove("hidden"); $("myName").textContent=username; connect(); requestAnimationFrame(loop); }
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault(); $("loginError").textContent="";
  try{
    const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("username").value,password:$("password").value})});
    const data=await r.json(); if(!r.ok) throw new Error(data.error||"Connexion impossible");
    token=data.token; username=data.username; $("password").value=""; showGame();
  }catch(err){$("loginError").textContent=err.message;}
});
function connect(){
  const proto=location.protocol==="https:"?"wss":"ws";
  socket=new WebSocket(`${proto}://${location.host}/world?token=${encodeURIComponent(token)}`);
  socket.onmessage=e=>{const d=JSON.parse(e.data);if(d.type==="welcome"||d.type==="players"){players=d.players||[];renderPlayers();}if(d.type==="chat")addMessage(d.username,d.message,d.time);};
  socket.onclose=()=>{if(!$("game").classList.contains("hidden"))setTimeout(()=>{if(token)connect()},1800);};
}
function renderPlayers(){
  $("onlineCount").textContent=players.length+" joueur"+(players.length>1?"s":"");
  $("countBadge").textContent=players.length;
  $("playersList").replaceChildren();
  players.forEach(p=>{const d=document.createElement("div");d.className="player-row";d.textContent=p.username+(p.username===username?" (toi)":"");$("playersList").append(d);});
}
function addMessage(name,message,time){
  const d=document.createElement("div");d.className="message";
  const b=document.createElement("b");b.textContent=name;
  const span=document.createElement("span");span.textContent=" : "+message;
  const t=document.createElement("time");t.textContent=new Date(time).toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"});
  d.append(b,span,t);$("messages").append(d);$("messages").scrollTop=$("messages").scrollHeight;
}
$("chatForm").addEventListener("submit",e=>{e.preventDefault();const message=$("chatInput").value.trim();if(message&&socket?.readyState===1)socket.send(JSON.stringify({type:"chat",message}));$("chatInput").value="";});
$("logout").onclick=()=>{token="";if(socket)socket.close();$("game").classList.add("hidden");$("login").classList.remove("hidden");$("username").value="";};
window.addEventListener("keydown",e=>{const k=e.key.toLowerCase();if(["arrowup","arrowdown","arrowleft","arrowright"," "].includes(k))e.preventDefault();keys[k]=true;});
window.addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
function drawWorld(){
  const scale=Math.min(canvas.width/900,canvas.height/600), camX=Math.max(0,Math.min(W-canvas.width/scale,myPos.x-canvas.width/scale/2)),camY=Math.max(0,Math.min(H-canvas.height/scale,myPos.y-canvas.height/scale/2));
  ctx.setTransform(scale,0,0,scale,0,0);ctx.fillStyle="#75c47d";ctx.fillRect(0,0,900,600);
  // chemin central
  ctx.fillStyle="#d8c38e";ctx.beginPath();ctx.moveTo(0,410);ctx.bezierCurveTo(230,320,360,490,560,360);ctx.bezierCurveTo(710,260,780,300,900,210);ctx.lineWidth=58;ctx.strokeStyle="#d8c38e";ctx.stroke();
  ctx.strokeStyle="#e8d7aa";ctx.lineWidth=3;ctx.setLineDash([12,14]);ctx.stroke();ctx.setLineDash([]);
  ctx.save();ctx.translate(-camX,-camY);
  // lac
  ctx.fillStyle="#62b8dc";ctx.beginPath();ctx.ellipse(1650,390,250,145,-.2,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle="#a2e2ef";ctx.lineWidth=7;ctx.stroke();
  trees.forEach(t=>{ctx.fillStyle="#286b45";ctx.beginPath();ctx.arc(t.x,t.y,22,0,7);ctx.fill();ctx.fillStyle="#3f965a";ctx.beginPath();ctx.arc(t.x-7,t.y-8,17,0,7);ctx.fill();ctx.fillStyle="#795436";ctx.fillRect(t.x-4,t.y+10,8,19);});
  rocks.forEach(r=>{ctx.fillStyle="#89949a";ctx.beginPath();ctx.ellipse(r.x,r.y,12,8,.3,0,7);ctx.fill();});
  // petite maison
  ctx.fillStyle="#f1d7a5";ctx.fillRect(360,230,110,85);ctx.fillStyle="#a95548";ctx.beginPath();ctx.moveTo(345,235);ctx.lineTo(415,180);ctx.lineTo(485,235);ctx.fill();ctx.fillStyle="#68483a";ctx.fillRect(402,265,27,50);
  players.forEach(p=>drawPlayer(p.x,p.y,p.username,p.username===username));
  ctx.restore();
}
function drawPlayer(x,y,name,mine){
  ctx.fillStyle="#0004";ctx.beginPath();ctx.ellipse(x,y+15,15,6,0,0,7);ctx.fill();
  ctx.fillStyle=mine?"#2258c9":"#db7b42";ctx.fillRect(x-10,y-18,20,26);
  ctx.fillStyle="#f2c59d";ctx.beginPath();ctx.arc(x,y-25,10,0,7);ctx.fill();
  ctx.fillStyle="#28374c";ctx.fillRect(x-10,y-31,20,6);
  ctx.font="bold 12px Arial";ctx.textAlign="center";ctx.lineWidth=3;ctx.strokeStyle="#24432e";ctx.strokeText(name,x,y-43);ctx.fillStyle="white";ctx.fillText(name,x,y-43);
}
function loop(){
  const speed=3.1;let dx=0,dy=0,dir="down";
  if(keys["z"]||keys["w"]||keys["arrowup"]){dy-=speed;dir="up";}
  if(keys["s"]||keys["arrowdown"]){dy+=speed;dir="down";}
  if(keys["q"]||keys["a"]||keys["arrowleft"]){dx-=speed;dir="left";}
  if(keys["d"]||keys["arrowright"]){dx+=speed;dir="right";}
  if(dx&&dy){dx*=.707;dy*=.707;}
  myPos.x=Math.max(25,Math.min(W-25,myPos.x+dx));myPos.y=Math.max(25,Math.min(H-25,myPos.y+dy));
  if(socket?.readyState===1 && Date.now()-lastSent>65 && (dx||dy)){socket.send(JSON.stringify({type:"move",x:myPos.x,y:myPos.y,direction:dir}));lastSent=Date.now();}
  // garder sa position synchronisée même à l'arrivée
  if(players.length===0)players=[{username,x:myPos.x,y:myPos.y}];
  if(!players.some(p=>p.username===username))players.push({username,x:myPos.x,y:myPos.y});
  const me=players.find(p=>p.username===username);if(me){me.x=myPos.x;me.y=myPos.y;}
  drawWorld();requestAnimationFrame(loop);
}
